# 🐙 GitHub Pages - Krok Po Kroku

## KROK 1: Utwórz Konto GitHub

1. **Idź na** https://github.com
2. **Kliknij** "Sign up" (prawy górny róg)
3. **Podaj:**
   - Email
   - Hasło
   - Nazwa użytkownika (np. `twoja_nazwa`)
4. **Kliknij** "Create account"
5. **Potwierdź email** (sprawdź mailbox)

✅ **Masz konto!**

---

## KROK 2: Utwórz Nowe Repozytorium

1. **Zaloguj się** na GitHub
2. **Kliknij "+"** w górnym prawym rogu
3. **Wybierz** "New repository"
4. **Wypełnij:**
   - **Repository name**: `eggplant-snake`
   - **Description** (opcjonalne): `🍆 Eggplant Snake Game`
   - **Public** - MUSI być zaznaczone ✅
5. **Kliknij** "Create repository"

✅ **Repozytorium utworzone!**

---

## KROK 3: Dodaj Plik HTML

### Opcja A: Przez Przeglądarkę (NAJPROŚCIEJ)

1. **Jesteś** na stronie repozytorium
2. **Kliknij** "Add file" → "Create new file"
3. **W nazwie pliku wpisz:** `index.html`
4. **W zawartości wklej** cały kod z pliku `eggplant_snake_simple.html`
   - Otwórz `eggplant_snake_simple.html` w edytorze
   - Zaznacz wszystko (Ctrl+A lub Cmd+A)
   - Skopiuj (Ctrl+C lub Cmd+C)
   - Wklej w GitHub
5. **Na dole** kliknij "Commit new file"

✅ **Plik dodany!**

### Opcja B: Upload Bezpośrednio

1. **Kliknij** "Add file" → "Upload files"
2. **Przeciągnij** plik `eggplant_snake_simple.html` na stronę
3. **Zmień nazwę** na `index.html` (jeśli trzeba)
4. **Kliknij** "Commit changes"

✅ **Plik wrzucony!**

---

## KROK 4: Włącz GitHub Pages

1. **W repozytorium** kliknij "Settings" (prawy górny róg)
2. **Po lewej** szukaj "Pages" (patrz zrzut poniżej)
3. **Pod "Source"** zaznacz:
   - Branch: `main`
   - Folder: `/ (root)`
4. **Kliknij** "Save"

⏳ **GitHub generuje link (czeka 2-5 minut)**

✅ **GitHub Pages włączony!**

---

## KROK 5: Skopiuj Link

1. **Idź znowu do** "Settings" → "Pages"
2. **Powinien być napis:**
   ```
   Your site is published at:
   https://TWOJA_NAZWA.github.io/eggplant-snake
   ```
3. **Skopiuj link**
4. **Testuj w przeglądarce** - powinna działać gra!

✅ **GOTA! MASZ LINK!**

---

## 🎯 TWÓJ LINK BĘDZIE WYGLĄDAĆ:

```
https://TWOJA_NAZWA.github.io/eggplant-snake
```

**Np. jeśli:**
- Twoja nazwa: `john123`
- Repo: `eggplant-snake`

**Link:**
```
https://john123.github.io/eggplant-snake
```

---

## 📱 Testuj Link

1. **Otwórz link w przeglądarce**
2. **Powinna się załadować gra**
3. **Sterowanie:**
   - Strzałkami lub WASD
   - SPACE - Pauza
   - R - Restart

✅ **Gotowe!**

---

## 🔗 Podziel Się Linkiem!

Teraz możesz wysłać link:

**Discord:**
```
Graj w moją grę! 🍆🐍
https://john123.github.io/eggplant-snake
```

**WhatsApp:**
```
Zrobiłem grę snake! https://john123.github.io/eggplant-snake
```

**Email:**
```
Hej!

Zrobiłem grę Eggplant Snake! Spróbuj:
https://john123.github.io/eggplant-snake

Sterowanie: Strzałkami lub WASD
SPACE - Pauza
R - Restart

Powodzenia!
```

---

## ❓ FAQ

**P: Gra nie działa na linku**
A: Czekaj 5 minut - GitHub generuje link. Odśwież stronę (Cmd+R).

**P: Zmieniam plik - kiedy się update'a?**
A: 1-2 minuty. Odśwież stronę (Cmd+R lub Ctrl+R).

**P: Mogę zmienić nazwę repozytorium?**
A: Tak! Settings → Danger Zone → Rename

**P: Mogę zmienić zawartość gry?**
A: Tak! Edytuj `index.html` w GitHub i commit.

**P: Mogę dodać więcej plików?**
A: Tak! Mogą być CSS, JS, obrazy - wszystko.

**P: Czy to bezpieczne?**
A: Tak! GitHub jest profesjonalnym serwerem.

---

## 🎓 Co Możesz Robić Dalej?

### Zmienić Grę:
1. Edytuj `index.html` w GitHub
2. Zmień coś (np. prędkość, kolory)
3. Commit
4. Odśwież link - zmiany widać!

### Dodać Opis:
1. Utwórz nowy plik: `README.md`
2. Dodaj opis gry w Markdown
3. Commit
4. Pojawi się na stronie repo

### Trackować Zmiany:
GitHub pokazuje historię każdego commita - możesz cofnąć do starszej wersji!

---

## 🚀 PODSUMOWANIE

1. ✅ GitHub account
2. ✅ Nowe repo: `eggplant-snake`
3. ✅ Plik: `index.html` (cały kod gry)
4. ✅ Settings → Pages → main branch
5. ✅ Czekaj 5 minut
6. ✅ Kopiuj link
7. ✅ Podziel się!

---

## 📞 Jeśli Coś Nie Działa

Daj znać jakie jest dokładnie **czarny ekran? błąd? coś innego?**

- Odśwież stronę (Cmd+R)
- Wyczyść cache (Cmd+Shift+Delete)
- Spróbuj w innej przeglądarce

---

**Powodzenia!** 🐙✨

Twoja gra będzie dostępna dla wszystkich na całym świecie! 🌍🍆🐍
